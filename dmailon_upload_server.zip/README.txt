INSTRUÇÕES:

1. Instale as dependências:
   npm install

2. Inicie o servidor:
   npm start

3. O servidor rodará em:
   http://localhost:3000

As imagens enviadas ficarão salvas em /uploads e acessíveis por URL.